#!/bin/bash
# Build and play ADarkRoom in a persistent iPhone simulator.
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$project_dir"

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  cat <<'HELP'
Usage: ./play.sh [SIMULATOR_UDID]

Builds ADarkRoom, installs it, and opens the game in an iPhone simulator.
Without an argument it creates or reuses a simulator named ADarkRoom.
Your game saves are kept on that simulator between launches.

Requires Xcode with an installed iOS Simulator runtime. No signing account needed.
Build details are written to Artifacts/play-build.log.
HELP
  exit 0
fi
if [[ $# -gt 1 ]]; then
  echo "Usage: ./play.sh [SIMULATOR_UDID]" >&2
  exit 1
fi

for required_command in xcodebuild xcrun python3 open; do
  if ! command -v "$required_command" >/dev/null 2>&1; then
    echo "Missing $required_command. Install Xcode and an iOS Simulator runtime first." >&2
    exit 1
  fi
done

mkdir -p Artifacts
python3 Scripts/vendor_original.py --verify
launch_temp="$(mktemp -d "${TMPDIR:-/tmp}/adarkroom-launch.XXXXXX")"
trap 'rm -rf "$launch_temp"' EXIT
xcrun simctl list devices available --json > "$launch_temp/devices.json"

selection="$(python3 - "$launch_temp/devices.json" "${1:-}" <<'PY'
import json, re, sys

with open(sys.argv[1]) as source:
    groups = json.load(source)["devices"]
requested = sys.argv[2]
devices = []
for runtime, entries in groups.items():
    if ".iOS-" not in runtime:
        continue
    version = tuple(int(n) for n in runtime.rsplit(".iOS-", 1)[1].split("-"))
    for entry in entries:
        if entry.get("isAvailable", True):
            devices.append((version, runtime, entry))
if requested:
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", requested):
        sys.exit("Please supply a simulator UDID, or run ./play.sh without an argument.")
    choices = [d for d in devices if d[2]["udid"].lower() == requested.lower()]
    if not choices:
        sys.exit("That iOS simulator is unavailable. Run xcrun simctl list devices available to find its UDID.")
else:
    choices = [d for d in devices if d[2]["name"] == "ADarkRoom"]
    if not choices:
        phones = [d for d in devices if ".iPhone-" in d[2].get("deviceTypeIdentifier", "")]
        if not phones:
            sys.exit("No iPhone simulator is installed. Install an iOS runtime and an iPhone simulator in Xcode first.")
        _, runtime, model = max(phones, key=lambda d: d[0])
        print("\t".join(["create", runtime, model["deviceTypeIdentifier"], "Shutdown"]))
        sys.exit(0)
_, runtime, device = max(choices, key=lambda d: d[0])
print("\t".join(["reuse", runtime, device["udid"], device["state"]]))
PY
)"
IFS=$'\t' read -r selection_mode simulator_runtime simulator_identifier simulator_state <<< "$selection"

if [[ "$selection_mode" == "create" ]]; then
  echo "Creating your ADarkRoom iPhone simulator…"
  simulator_identifier="$(xcrun simctl create 'ADarkRoom' "$simulator_identifier" "$simulator_runtime")"
fi
if [[ "$simulator_state" != "Booted" ]]; then
  echo "Starting the iPhone simulator…"
  xcrun simctl boot "$simulator_identifier"
fi
xcrun simctl bootstatus "$simulator_identifier" -b > "$launch_temp/boot.log" 2>&1

echo "Building ADarkRoom (the first run can take a few minutes)…"
if ! xcodebuild -project ADarkRoom.xcodeproj -scheme ADarkRoom \
    -configuration Debug -destination "platform=iOS Simulator,id=$simulator_identifier" \
    -derivedDataPath Artifacts/Build CODE_SIGNING_ALLOWED=NO build \
    > Artifacts/play-build.log 2>&1; then
  tail -n 40 Artifacts/play-build.log >&2
  echo "Build failed. Full details: $project_dir/Artifacts/play-build.log" >&2
  exit 1
fi

app_path="$project_dir/Artifacts/Build/Build/Products/Debug-iphonesimulator/ADarkRoom.app"
echo "Opening the game…"
xcrun simctl install "$simulator_identifier" "$app_path"
# Normal launch: no showcase fixtures, reset, or isolated test saves.
xcrun simctl launch "$simulator_identifier" com.adarkroom.game

developer_dir="$(xcode-select -p)"
simulator_app="$developer_dir/Applications/Simulator.app"
device_hub_app="${developer_dir%/Developer}/Applications/DeviceHub.app"
if [[ -d "$simulator_app" ]]; then
  open "$simulator_app" --args -CurrentDeviceUDID "$simulator_identifier"
elif [[ -d "$device_hub_app" ]]; then
  open "$device_hub_app"
  echo "In Device Hub, select ADarkRoom in the sidebar (or your chosen simulator)."
elif open -Ra Simulator >/dev/null 2>&1; then
  open -a Simulator --args -CurrentDeviceUDID "$simulator_identifier"
else
  echo "The game is running. Open Xcode's simulator viewer and select $simulator_identifier."
fi
echo "Ready to play. Tap light fire; your progress saves automatically."
