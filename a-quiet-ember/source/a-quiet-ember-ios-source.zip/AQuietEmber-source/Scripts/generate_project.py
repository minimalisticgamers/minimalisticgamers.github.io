#!/usr/bin/env python3
"""Rebuild the dependency-free Xcode project. Requires Xcode 16 or newer."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "ADarkRoom.xcodeproj"
PROJECT.mkdir(exist_ok=True)

project = r'''// !$*UTF8*$!
{
 archiveVersion = 1;
 classes = {};
 objectVersion = 77;
 objects = {
  A00000000000000000000001 = {isa = PBXProject; attributes = {BuildIndependentTargetsInParallel = 1; LastUpgradeCheck = 2700; TargetAttributes = {A00000000000000000000010 = {CreatedOnToolsVersion = 27.0;}; A00000000000000000000011 = {CreatedOnToolsVersion = 27.0; TestTargetID = A00000000000000000000010;}; A00000000000000000000012 = {CreatedOnToolsVersion = 27.0; TestTargetID = A00000000000000000000010;};};}; buildConfigurationList = A00000000000000000000030; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en, Base); mainGroup = A00000000000000000000002; minimizedProjectReferenceProxies = 1; packageReferences = (); preferredProjectObjectVersion = 77; productRefGroup = A00000000000000000000006; projectDirPath = ""; projectRoot = ""; targets = (A00000000000000000000010, A00000000000000000000011, A00000000000000000000012);};
  A00000000000000000000002 = {isa = PBXGroup; children = (A00000000000000000000003, A00000000000000000000004, A00000000000000000000005, A00000000000000000000070, A00000000000000000000006); sourceTree = "<group>";};
  A00000000000000000000003 = {isa = PBXFileSystemSynchronizedRootGroup; exceptions = (A00000000000000000000007); path = ADarkRoom; sourceTree = "<group>";};
  A00000000000000000000004 = {isa = PBXFileSystemSynchronizedRootGroup; path = ADarkRoomTests; sourceTree = "<group>";};
  A00000000000000000000005 = {isa = PBXFileSystemSynchronizedRootGroup; path = ADarkRoomUITests; sourceTree = "<group>";};
  A00000000000000000000006 = {isa = PBXGroup; children = (A00000000000000000000008, A00000000000000000000009, A0000000000000000000000A); name = Products; sourceTree = "<group>";};
  A00000000000000000000007 = {isa = PBXFileSystemSynchronizedBuildFileExceptionSet; membershipExceptions = (Info.plist); target = A00000000000000000000010;};
  A00000000000000000000008 = {isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = ADarkRoom.app; sourceTree = BUILT_PRODUCTS_DIR;};
  A00000000000000000000009 = {isa = PBXFileReference; explicitFileType = wrapper.cfbundle; includeInIndex = 0; path = ADarkRoomTests.xctest; sourceTree = BUILT_PRODUCTS_DIR;};
  A0000000000000000000000A = {isa = PBXFileReference; explicitFileType = wrapper.cfbundle; includeInIndex = 0; path = ADarkRoomUITests.xctest; sourceTree = BUILT_PRODUCTS_DIR;};
  A00000000000000000000010 = {isa = PBXNativeTarget; buildConfigurationList = A00000000000000000000031; buildPhases = (A00000000000000000000020, A00000000000000000000021, A00000000000000000000022); buildRules = (); dependencies = (); fileSystemSynchronizedGroups = (A00000000000000000000003); name = ADarkRoom; packageProductDependencies = (); productName = ADarkRoom; productReference = A00000000000000000000008; productType = "com.apple.product-type.application";};
  A00000000000000000000011 = {isa = PBXNativeTarget; buildConfigurationList = A00000000000000000000032; buildPhases = (A00000000000000000000023, A00000000000000000000024, A00000000000000000000025); buildRules = (); dependencies = (A00000000000000000000060); fileSystemSynchronizedGroups = (A00000000000000000000004); name = ADarkRoomTests; packageProductDependencies = (); productName = ADarkRoomTests; productReference = A00000000000000000000009; productType = "com.apple.product-type.bundle.unit-test";};
  A00000000000000000000012 = {isa = PBXNativeTarget; buildConfigurationList = A00000000000000000000033; buildPhases = (A00000000000000000000026, A00000000000000000000027, A00000000000000000000028); buildRules = (); dependencies = (A00000000000000000000061); fileSystemSynchronizedGroups = (A00000000000000000000005); name = ADarkRoomUITests; packageProductDependencies = (); productName = ADarkRoomUITests; productReference = A0000000000000000000000A; productType = "com.apple.product-type.bundle.ui-testing";};
  A00000000000000000000020 = {isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000021 = {isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000022 = {isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (A00000000000000000000071); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000023 = {isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000024 = {isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000025 = {isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000026 = {isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000027 = {isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000028 = {isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;};
  A00000000000000000000030 = {isa = XCConfigurationList; buildConfigurations = (A00000000000000000000040, A00000000000000000000041); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;};
  A00000000000000000000031 = {isa = XCConfigurationList; buildConfigurations = (A00000000000000000000042, A00000000000000000000043); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;};
  A00000000000000000000032 = {isa = XCConfigurationList; buildConfigurations = (A00000000000000000000044, A00000000000000000000045); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;};
  A00000000000000000000033 = {isa = XCConfigurationList; buildConfigurations = (A00000000000000000000046, A00000000000000000000047); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;};
  A00000000000000000000040 = {isa = XCBuildConfiguration; buildSettings = {ALWAYS_SEARCH_USER_PATHS = NO; CLANG_ENABLE_MODULES = YES; CLANG_ENABLE_OBJC_ARC = YES; CLANG_WARN_DOCUMENTATION_COMMENTS = YES; CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER = YES; COPY_PHASE_STRIP = NO; DEBUG_INFORMATION_FORMAT = dwarf; ENABLE_TESTABILITY = YES; GCC_C_LANGUAGE_STANDARD = gnu17; GCC_OPTIMIZATION_LEVEL = 0; GCC_PREPROCESSOR_DEFINITIONS = ("DEBUG=1", "$(inherited)"); IPHONEOS_DEPLOYMENT_TARGET = 17.0; ONLY_ACTIVE_ARCH = YES; SDKROOT = iphoneos; SWIFT_ACTIVE_COMPILATION_CONDITIONS = "DEBUG $(inherited)"; SWIFT_OPTIMIZATION_LEVEL = "-Onone"; SWIFT_VERSION = 5.0;}; name = Debug;};
  A00000000000000000000041 = {isa = XCBuildConfiguration; buildSettings = {ALWAYS_SEARCH_USER_PATHS = NO; CLANG_ENABLE_MODULES = YES; CLANG_ENABLE_OBJC_ARC = YES; CLANG_WARN_DOCUMENTATION_COMMENTS = YES; CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER = YES; COPY_PHASE_STRIP = NO; DEBUG_INFORMATION_FORMAT = "dwarf-with-dsym"; GCC_C_LANGUAGE_STANDARD = gnu17; IPHONEOS_DEPLOYMENT_TARGET = 17.0; SDKROOT = iphoneos; SWIFT_COMPILATION_MODE = wholemodule; SWIFT_OPTIMIZATION_LEVEL = "-O"; SWIFT_VERSION = 5.0; VALIDATE_PRODUCT = YES;}; name = Release;};
  A00000000000000000000042 = {isa = XCBuildConfiguration; buildSettings = {ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon; ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME = AccentColor; CODE_SIGN_STYLE = Automatic; CURRENT_PROJECT_VERSION = 1; DEVELOPMENT_TEAM = ""; ENABLE_USER_SCRIPT_SANDBOXING = YES; GENERATE_INFOPLIST_FILE = YES; INFOPLIST_FILE = ADarkRoom/Info.plist; INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES; INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents = YES; LD_RUNPATH_SEARCH_PATHS = ("$(inherited)", "@executable_path/Frameworks"); MARKETING_VERSION = 1.0; PRODUCT_BUNDLE_IDENTIFIER = com.adarkroom.game; PRODUCT_NAME = "$(TARGET_NAME)"; SUPPORTED_PLATFORMS = "iphoneos iphonesimulator"; SUPPORTS_MACCATALYST = NO; SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD = NO; SWIFT_EMIT_LOC_STRINGS = YES; TARGETED_DEVICE_FAMILY = "1,2";}; name = Debug;};
  A00000000000000000000043 = {isa = XCBuildConfiguration; buildSettings = {ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon; ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME = AccentColor; CODE_SIGN_STYLE = Automatic; CURRENT_PROJECT_VERSION = 3; DEVELOPMENT_TEAM = 6628NY8NAD; ENABLE_USER_SCRIPT_SANDBOXING = YES; GENERATE_INFOPLIST_FILE = YES; INFOPLIST_FILE = ADarkRoom/Info.plist; INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES; INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents = YES; LD_RUNPATH_SEARCH_PATHS = ("$(inherited)", "@executable_path/Frameworks"); MARKETING_VERSION = 1.0; PRODUCT_BUNDLE_IDENTIFIER = com.skylar.adarkroom; PRODUCT_NAME = "$(TARGET_NAME)"; SUPPORTED_PLATFORMS = "iphoneos iphonesimulator"; SUPPORTS_MACCATALYST = NO; SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD = NO; SWIFT_EMIT_LOC_STRINGS = YES; TARGETED_DEVICE_FAMILY = "1,2";}; name = Release;};
  A00000000000000000000044 = {isa = XCBuildConfiguration; buildSettings = {BUNDLE_LOADER = "$(TEST_HOST)"; CODE_SIGN_STYLE = Automatic; GENERATE_INFOPLIST_FILE = YES; PRODUCT_BUNDLE_IDENTIFIER = com.adarkroom.game.tests; PRODUCT_NAME = "$(TARGET_NAME)"; TARGETED_DEVICE_FAMILY = "1,2"; TEST_HOST = "$(BUILT_PRODUCTS_DIR)/ADarkRoom.app/$(BUNDLE_EXECUTABLE_FOLDER_PATH)/ADarkRoom";}; name = Debug;};
  A00000000000000000000045 = {isa = XCBuildConfiguration; buildSettings = {BUNDLE_LOADER = "$(TEST_HOST)"; CODE_SIGN_STYLE = Automatic; GENERATE_INFOPLIST_FILE = YES; PRODUCT_BUNDLE_IDENTIFIER = com.adarkroom.game.tests; PRODUCT_NAME = "$(TARGET_NAME)"; TARGETED_DEVICE_FAMILY = "1,2"; TEST_HOST = "$(BUILT_PRODUCTS_DIR)/ADarkRoom.app/$(BUNDLE_EXECUTABLE_FOLDER_PATH)/ADarkRoom";}; name = Release;};
  A00000000000000000000046 = {isa = XCBuildConfiguration; buildSettings = {CODE_SIGN_STYLE = Automatic; GENERATE_INFOPLIST_FILE = YES; PRODUCT_BUNDLE_IDENTIFIER = com.adarkroom.game.uitests; PRODUCT_NAME = "$(TARGET_NAME)"; TARGETED_DEVICE_FAMILY = "1,2"; TEST_TARGET_NAME = ADarkRoom;}; name = Debug;};
  A00000000000000000000047 = {isa = XCBuildConfiguration; buildSettings = {CODE_SIGN_STYLE = Automatic; GENERATE_INFOPLIST_FILE = YES; PRODUCT_BUNDLE_IDENTIFIER = com.adarkroom.game.uitests; PRODUCT_NAME = "$(TARGET_NAME)"; TARGETED_DEVICE_FAMILY = "1,2"; TEST_TARGET_NAME = ADarkRoom;}; name = Release;};
  A00000000000000000000070 = {isa = PBXFileReference; lastKnownFileType = folder; name = Vendor; path = Vendor; sourceTree = "<group>";};
  A00000000000000000000071 = {isa = PBXBuildFile; fileRef = A00000000000000000000070;};
  A00000000000000000000060 = {isa = PBXTargetDependency; target = A00000000000000000000010; targetProxy = A00000000000000000000062;};
  A00000000000000000000061 = {isa = PBXTargetDependency; target = A00000000000000000000010; targetProxy = A00000000000000000000063;};
  A00000000000000000000062 = {isa = PBXContainerItemProxy; containerPortal = A00000000000000000000001; proxyType = 1; remoteGlobalIDString = A00000000000000000000010; remoteInfo = ADarkRoom;};
  A00000000000000000000063 = {isa = PBXContainerItemProxy; containerPortal = A00000000000000000000001; proxyType = 1; remoteGlobalIDString = A00000000000000000000010; remoteInfo = ADarkRoom;};
 };
 rootObject = A00000000000000000000001;
}
'''
(PROJECT / "project.pbxproj").write_text(project)
schemes = PROJECT / "xcshareddata" / "xcschemes"
schemes.mkdir(parents=True, exist_ok=True)
ref = '<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="A00000000000000000000010" BuildableName="ADarkRoom.app" BlueprintName="ADarkRoom" ReferencedContainer="container:ADarkRoom.xcodeproj"/>'
tests = "\n".join(f'''<TestableReference skipped="NO"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{identifier}" BuildableName="{name}.xctest" BlueprintName="{name}" ReferencedContainer="container:ADarkRoom.xcodeproj"/></TestableReference>''' for identifier, name in [("A00000000000000000000011", "ADarkRoomTests"), ("A00000000000000000000012", "ADarkRoomUITests")])
(schemes / "ADarkRoom.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2700" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{ref}</BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables>{tests}</Testables></TestAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{ref}</BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{ref}</BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/>
<ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''')
print("Generated ADarkRoom.xcodeproj and shared ADarkRoom scheme.")
