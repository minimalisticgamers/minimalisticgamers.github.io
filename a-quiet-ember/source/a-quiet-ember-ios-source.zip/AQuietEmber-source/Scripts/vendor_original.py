#!/usr/bin/env python3
"""Verify the frozen official hosted game; refresh only when explicitly requested.

No third-party Python packages are required. Verification never accesses the network.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tempfile
from urllib.parse import urljoin, urlsplit

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / "Vendor" / "ADarkRoom"
MANIFEST = VENDOR / "source-manifest.json"
ORIGIN = "https://adarkroom.doublespeakgames.com/"


def safe_path(value: str) -> bool:
    path = PurePosixPath(value)
    return bool(value) and not path.is_absolute() and "\\" not in value and all(
        piece not in ("", ".", "..") for piece in value.split("/")
    )


def read_manifest() -> dict:
    manifest = json.loads(MANIFEST.read_text())
    assert manifest["formatVersion"] == 1
    assert manifest["origin"] == ORIGIN
    assert manifest["entryPoint"] == "index.html"
    paths = [item["path"] for item in manifest["files"]]
    assert len(paths) == len(set(paths)), "Duplicate source path"
    assert all(safe_path(path) for path in paths), "Unsafe source path"
    assert "index.html" in paths and "LICENSE.md" in paths
    for item in manifest["files"]:
        assert item["sourceUrl"] == urljoin(ORIGIN, item["path"])
    return manifest


def dependencies(directory: Path, manifest: dict) -> None:
    """Check entry assets, local warning pages, audio, and dynamic translations."""
    paths = {item["path"] for item in manifest["files"]}
    class References(HTMLParser):
        def __init__(self):
            super().__init__()
            self.references = []

        def handle_starttag(self, tag, attributes):
            self.references.extend(value for key, value in attributes if key in ("src", "href") and value)

    for page in ("index.html", "browserWarning.html", "mobileWarning.html"):
        source = (directory / page).read_text()
        parsed = References()
        parsed.feed(source)
        for reference in parsed.references:
            if any(character in reference for character in ("+", "\\")):
                continue  # document.write expressions are checked below.
            if urlsplit(reference).scheme or reference.startswith(("//", "#")):
                continue
            target = urlsplit(urljoin(ORIGIN + page, reference)).path.lstrip("/")
            assert target in paths, f"Missing {page} dependency: {target}"
    for required in ("lib/jquery.min.js", "css/dark.css"):
        assert required in paths, f"Missing dynamic dependency: {required}"
    audio = (directory / "script/audioLibrary.js").read_text()
    audio_paths = set(re.findall(r"['\"](audio/[^'\"]+\.flac)['\"]", audio))
    assert audio_paths, "No audio definitions found"
    assert audio_paths <= paths, f"Missing audio: {sorted(audio_paths - paths)}"
    languages = re.findall(r"^\s*'([^']+)'\s*:", (directory / "lang/langs.js").read_text(), re.M)
    for language in languages:
        if language != "en":
            assert f"lang/{language}/strings.js" in paths, f"Missing translation: {language}"
    # Latvian has no main.css in the official source; its strings use default CSS.
    for language in languages:
        if language not in ("en", "lv"):
            assert f"lang/{language}/main.css" in paths, f"Missing translation stylesheet: {language}"
    print(f"Dependencies verified: {len(audio_paths)} audio files and {len(languages)} languages.")


def verify(directory: Path, manifest: dict) -> None:
    for item in manifest["files"]:
        path = directory / item["path"]
        assert not path.is_symlink(), f"Source must not be a symlink: {item['path']}"
        data = path.read_bytes()
        assert len(data) == item["sizeBytes"], f"Size mismatch: {item['path']}"
        assert hashlib.sha256(data).hexdigest() == item["sha256"], f"SHA-256 mismatch: {item['path']}"
    dependencies(directory, manifest)
    print(f"Verified {len(manifest['files'])} original hosted files ({sum(i['sizeBytes'] for i in manifest['files']):,} bytes).")


def download(directory: Path, manifest: dict) -> None:
    def fetch(item: dict) -> None:
        target = directory / item["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        # The official host rejects urllib's default client; curl is accepted.
        subprocess.run([
            "curl", "--fail", "--silent", "--show-error", "--location",
            "--retry", "2", "--max-time", "45", item["sourceUrl"], "--output", str(target),
        ], check=True)
    with ThreadPoolExecutor(max_workers=8) as executor:
        list(executor.map(fetch, manifest["files"]))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--verify", action="store_true", help="Verify pinned files offline; never update them")
    action.add_argument("--verify-hosted", action="store_true", help="Download into temporary storage and compare the current official host with the pin")
    action.add_argument("--refresh", action="store_true", help="Intentionally replace the pinned snapshot from its official source URLs")
    arguments = parser.parse_args()
    manifest = read_manifest()
    if arguments.verify:
        verify(VENDOR, manifest)
        return
    with tempfile.TemporaryDirectory(prefix="adarkroom-source-") as temporary:
        directory = Path(temporary)
        download(directory, manifest)
        if arguments.verify_hosted:
            verify(directory, manifest)
            print("Current official hosted bytes match the pinned snapshot.")
            return
        for item in manifest["files"]:
            data = (directory / item["path"]).read_bytes()
            new_hash = hashlib.sha256(data).hexdigest()
            if new_hash != item["sha256"]:
                item.pop("matchesUpstreamCommit", None)
            item["sha256"] = new_hash
            item["sizeBytes"] = len(data)
        manifest["retrievedAt"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
        dependencies(directory, manifest)
        verify(directory, manifest)
        for item in manifest["files"]:
            shutil.copyfile(directory / item["path"], VENDOR / item["path"])
        MANIFEST.write_text(json.dumps(manifest, indent=2) + "\n")
        print("Snapshot intentionally refreshed. Review source and manifest changes before committing.")


if __name__ == "__main__":
    main()
