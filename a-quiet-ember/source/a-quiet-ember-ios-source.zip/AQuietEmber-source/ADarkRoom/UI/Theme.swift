import SwiftUI

/// Quiet, full-width controls with comfortable iPhone touch targets.
struct TerminalButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(.body, design: .serif))
            .foregroundStyle(isEnabled ? Color.black : Color(white: 0.5))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .frame(minHeight: 48)
            .background(Color(white: configuration.isPressed && isEnabled ? 0.88 : 0.98),
                        in: RoundedRectangle(cornerRadius: 5))
            .overlay(RoundedRectangle(cornerRadius: 5)
                .stroke(Color(white: isEnabled ? 0.72 : 0.86), lineWidth: 0.75))
            .contentShape(Rectangle())
    }
}
