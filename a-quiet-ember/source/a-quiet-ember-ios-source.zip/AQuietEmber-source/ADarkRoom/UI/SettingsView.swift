import SwiftUI
import UniformTypeIdentifiers

struct SettingsView: View {
    @EnvironmentObject private var game: OriginalGameController
    @Environment(\.dismiss) private var dismiss
    @State private var message: String?
    @State private var isWorking = false
    @State private var showExporter = false
    @State private var showImporter = false
    @State private var showImportConfirmation = false
    @State private var showResetConfirmation = false
    @State private var pendingImport: Data?
    @State private var exportDocument: OriginalSaveDocument?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Your progress")
                            .font(.system(.title2, design: .serif))
                        Text("The game saves automatically. Export a copy to keep a backup or continue on another device.")
                            .font(.system(.subheadline, design: .serif))
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Button {
                            perform {
                                try await game.saveNow()
                                message = "Saved."
                            }
                        } label: {
                            SettingsActionLabel(title: "Save now", symbol: "checkmark.circle")
                        }
                        .accessibilityIdentifier("saveNow")
                        Button {
                            perform {
                                try await game.saveNow()
                                exportDocument = OriginalSaveDocument(data: try await game.exportSave())
                                showExporter = true
                            }
                        } label: {
                            SettingsActionLabel(title: "Export save", symbol: "square.and.arrow.up")
                        }
                        .accessibilityIdentifier("exportSave")
                        Button { showImporter = true } label: {
                            SettingsActionLabel(title: "Import save", symbol: "square.and.arrow.down")
                        }
                        .accessibilityIdentifier("importSave")
                    }
                    .buttonStyle(TerminalButtonStyle())
                    .disabled(!game.isLoaded || isWorking)

                    if isWorking {
                        ProgressView("Saving progress…")
                            .font(.system(.subheadline, design: .serif))
                    }
                    if let message {
                        Text(message)
                            .font(.system(.subheadline, design: .serif))
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(white: 0.95), in: RoundedRectangle(cornerRadius: 5))
                            .accessibilityIdentifier("saveStatus")
                    }

                    Divider()
                    DisclosureGroup {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("The game and saves are stored on this device. No account is required. An exported save is shared only when you choose a destination. Device backups and optional diagnostics follow your Apple settings.")
                            if let url = configuredWebURL("ADarkRoomSupportURL") {
                                Link("Support", destination: url).frame(minHeight: 44)
                            }
                            if let url = supportEmailURL {
                                Link("Email support", destination: url).frame(minHeight: 44)
                            }
                            if let url = configuredWebURL("ADarkRoomPrivacyPolicyURL") {
                                Link("Privacy policy", destination: url).frame(minHeight: 44)
                            }
                        }
                        .font(.system(.subheadline, design: .serif))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 8)
                    } label: {
                        Text("Privacy & support").frame(minHeight: 44)
                    }

                    DisclosureGroup {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Original game: A Dark Room by Michael Townsend and contributors (doublespeak games).")
                            Link("Original website", destination: URL(string: "https://adarkroom.doublespeakgames.com/")!)
                                .frame(minHeight: 44)
                            Link("Original source · MPL 2.0", destination: URL(string: "https://github.com/doublespeakgames/adarkroom")!)
                                .frame(minHeight: 44)
                            Text("A Quiet Ember is an independent iOS adaptation of the original browser game. Original credits and license notices are retained.")
                            if let url = configuredWebURL("ADarkRoomSourceURL") {
                                Link("Complete source code", destination: url).frame(minHeight: 44)
                            }
                            NavigationLink("Open-source licenses") {
                                LicenseNoticesView()
                            }
                            .frame(minHeight: 44)
                            .accessibilityIdentifier("openSourceLicenses")
                        }
                        .font(.system(.subheadline, design: .serif))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 8)
                    } label: {
                        Text("Credits").frame(minHeight: 44)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Divider()
                        Text("Start over")
                            .font(.system(.headline, design: .serif))
                            .padding(.top, 8)
                        Text("Begin a new run. Export your current save if you want to keep it.")
                            .font(.system(.subheadline, design: .serif))
                            .foregroundStyle(.secondary)
                        Button { showResetConfirmation = true } label: {
                            SettingsActionLabel(title: "Reset game", symbol: "arrow.counterclockwise")
                        }
                        .buttonStyle(TerminalButtonStyle())
                        .disabled(!game.isLoaded || isWorking)
                        .accessibilityIdentifier("resetGame")
                        Text("Version \(version)")
                            .font(.system(.caption, design: .serif))
                            .foregroundStyle(.secondary)
                            .padding(.top, 4)
                    }
                }
                .font(.system(.body, design: .serif))
                .frame(maxWidth: 560, alignment: .leading)
                .padding(20)
                .frame(maxWidth: .infinity)
            }
            .background(Color.white)
            .foregroundStyle(Color.black)
            .tint(.black)
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                        .frame(minWidth: 44, minHeight: 44)
                }
            }
            .fileExporter(isPresented: $showExporter, document: exportDocument,
                          contentType: .json, defaultFilename: "a-dark-room-save") { result in
                switch result {
                case .success: message = "Save exported."
                case .failure(let error): report(error)
                }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json],
                          allowsMultipleSelection: false) { result in
                do {
                    guard let url = try result.get().first else { return }
                    let scoped = url.startAccessingSecurityScopedResource()
                    defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                    let data = try Data(contentsOf: url, options: .mappedIfSafe)
                    guard data.count <= 8 * 1_024 * 1_024 else {
                        throw SaveDocumentError.tooLarge
                    }
                    pendingImport = data
                    showImportConfirmation = true
                } catch { report(error) }
            }
            .alert("Replace current save?", isPresented: $showImportConfirmation) {
                Button("Import save", role: .destructive) {
                    guard let data = pendingImport else { return }
                    pendingImport = nil
                    perform {
                        try await game.importSave(data)
                        message = "Save imported."
                    }
                }
                Button("Cancel", role: .cancel) { pendingImport = nil }
            } message: {
                Text("This replaces the current original-game save with the selected file.")
            }
            .alert("Reset game?", isPresented: $showResetConfirmation) {
                Button("Reset game", role: .destructive) {
                    perform {
                        try await game.resetRun()
                        message = "Game reset."
                        dismiss()
                    }
                }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("This clears the current run using the original game’s reset. Export your save first if you want to keep it.")
            }
        }
    }

    private func perform(_ operation: @escaping @MainActor () async throws -> Void) {
        guard !isWorking else { return }
        isWorking = true
        message = nil
        Task { @MainActor in
            defer { isWorking = false }
            do { try await operation() }
            catch { report(error) }
        }
    }

    private func report(_ error: Error) {
        if let cocoa = error as? CocoaError, cocoa.code == .userCancelled { return }
        message = error.localizedDescription
    }

    private var version: String {
        let short = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
        return "\(short) (\(build))"
    }

    private var supportEmailURL: URL? {
        guard let email = configuredString("ADarkRoomSupportEmail"),
              email.split(separator: "@", omittingEmptySubsequences: false).count == 2,
              !email.hasPrefix("@"), !email.hasSuffix("@"),
              email.rangeOfCharacter(from: .whitespacesAndNewlines) == nil,
              email.rangeOfCharacter(from: .controlCharacters) == nil,
              !email.contains("?"), !email.contains("#") else { return nil }
        var parts = URLComponents()
        parts.scheme = "mailto"
        parts.path = email
        return parts.url
    }

    private func configuredWebURL(_ key: String) -> URL? {
        guard let value = configuredString(key), let url = URL(string: value),
              let scheme = url.scheme?.lowercased(), ["https", "http"].contains(scheme),
              let host = url.host, !host.isEmpty,
              url.user == nil, url.password == nil else { return nil }
        return url
    }

    private func configuredString(_ key: String) -> String? {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: key) as? String else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? nil : value
    }
}

private struct SettingsActionLabel: View {
    let title: String
    let symbol: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 17))
                .frame(width: 22)
                .accessibilityHidden(true)
            Text(title)
            Spacer(minLength: 0)
        }
    }
}

private struct OriginalSaveDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data

    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.data = data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

private enum SaveDocumentError: LocalizedError {
    case tooLarge
    var errorDescription: String? { "This save file is too large to import." }
}
