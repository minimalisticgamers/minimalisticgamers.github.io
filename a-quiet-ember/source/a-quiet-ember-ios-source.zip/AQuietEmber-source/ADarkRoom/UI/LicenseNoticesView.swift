import SwiftUI

struct LicenseNoticesView: View {
    private var notices: String {
        guard let url = Bundle.main.url(forResource: "THIRD_PARTY_NOTICES", withExtension: "txt"),
              let text = try? String(contentsOf: url, encoding: .utf8) else {
            return "License notices could not be loaded. Complete source and licenses are also available from Settings → Credits → Complete source code."
        }
        return text
    }

    var body: some View {
        ScrollView {
            Text(notices)
                .font(.system(.footnote, design: .monospaced))
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(20)
        }
        .background(Color.white)
        .foregroundStyle(Color.black)
        .navigationTitle("Open-source licenses")
        .navigationBarTitleDisplayMode(.inline)
    }
}
