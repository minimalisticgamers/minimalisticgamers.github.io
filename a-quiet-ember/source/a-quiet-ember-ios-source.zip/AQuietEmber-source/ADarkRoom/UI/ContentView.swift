import SwiftUI
import WebKit

struct ContentView: View {
    @EnvironmentObject private var game: OriginalGameController
    @State private var showSettings = false
    private var paper: Color { game.isDark ? .black : .white }
    private var ink: Color { game.isDark ? .white : .black }

    var body: some View {
        VStack(spacing: 0) {
            if let error = game.errorMessage {
                HStack(alignment: .center, spacing: 12) {
                    Text(error)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Button("Retry") { Task { await game.retry() } }
                        .frame(minWidth: 60, minHeight: 44)
                }
                .font(.system(.footnote, design: .serif))
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
            }
            OriginalGameView(webView: game.webView)
                .overlay {
                    if !game.isLoaded && game.errorMessage == nil {
                        VStack(spacing: 12) {
                            ProgressView().tint(ink)
                            Text("A Quiet Ember")
                                .font(.system(.title3, design: .serif))
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(paper)
                        .accessibilityLabel("Loading A Quiet Ember")
                    }
                }
        }
        .background(paper)
        .foregroundStyle(ink)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            HStack(alignment: .center, spacing: 12) {
                if game.needsDirectionalControls {
                    DirectionPad(game: game, ink: ink)
                    Text("Move")
                        .font(.system(.caption, design: .serif))
                        .foregroundStyle(ink.opacity(0.65))
                        .fixedSize(horizontal: false, vertical: true)
                        .layoutPriority(-1)
                } else {
                    Text("A Quiet Ember")
                        .font(.system(.body, design: .serif))
                }
                Spacer(minLength: 0)
                Button {
                    game.releaseDirections()
                    showSettings = true
                } label: {
                    Group {
                        if game.needsDirectionalControls {
                            Image(systemName: "gearshape")
                        } else {
                            Label("Settings", systemImage: "gearshape")
                        }
                    }
                    .font(.system(.subheadline, design: .serif))
                    .padding(.horizontal, game.needsDirectionalControls ? 0 : 12)
                    .frame(minWidth: 44, minHeight: 44)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .background(ink.opacity(0.04), in: RoundedRectangle(cornerRadius: 4))
                .overlay(RoundedRectangle(cornerRadius: 4).stroke(ink.opacity(0.18), lineWidth: 1))
                .accessibilityLabel("Settings")
                .accessibilityIdentifier("settings")
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(paper)
            .overlay(alignment: .top) {
                Rectangle().fill(ink.opacity(0.14)).frame(height: 0.5)
            }
        }
        .preferredColorScheme(game.isDark ? .dark : .light)
        .task { await game.start() }
        .task {
            while !Task.isCancelled {
                await game.updatePresentation()
                try? await Task.sleep(for: .milliseconds(300))
            }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(game)
                .preferredColorScheme(.light)
                .presentationDragIndicator(.visible)
        }
    }
}

private struct OriginalGameView: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) { }
}

private struct DirectionPad: View {
    @ObservedObject var game: OriginalGameController
    let ink: Color

    var body: some View {
        VStack(spacing: 4) {
            DirectionKey(game: game, key: 38, symbol: "arrow.up", label: "Move north", ink: ink)
            HStack(spacing: 4) {
                DirectionKey(game: game, key: 37, symbol: "arrow.left", label: "Move west", ink: ink)
                DirectionKey(game: game, key: 40, symbol: "arrow.down", label: "Move south", ink: ink)
                DirectionKey(game: game, key: 39, symbol: "arrow.right", label: "Move east", ink: ink)
            }
        }
        .fixedSize()
        .onDisappear { game.releaseDirections() }
    }
}

private struct DirectionKey: View {
    @ObservedObject var game: OriginalGameController
    let key: Int
    let symbol: String
    let label: String
    let ink: Color
    @State private var held = false
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: 18, weight: .medium))
            .foregroundStyle(ink)
            .frame(width: 44, height: 44)
            .background(ink.opacity(held ? 0.18 : 0.04), in: RoundedRectangle(cornerRadius: 4))
            .overlay(RoundedRectangle(cornerRadius: 4).stroke(ink.opacity(held ? 0.7 : 0.3), lineWidth: 1))
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    if !held { held = true; game.sendDirection(key, pressed: true) }
                }
                .onEnded { _ in held = false; game.sendDirection(key, pressed: false) })
            .accessibilityLabel(label)
            .accessibilityHint("Move in this direction")
            .accessibilityIdentifier("direction-\(key)")
            .accessibilityAddTraits(.isButton)
            .accessibilityAction {
                game.sendDirection(key, pressed: true)
                Task { @MainActor in
                    try? await Task.sleep(for: .milliseconds(150))
                    game.sendDirection(key, pressed: false)
                }
            }
            .onDisappear { if held { game.sendDirection(key, pressed: false); held = false } }
            .onChange(of: scenePhase) { _, phase in
                if phase != .active { game.sendDirection(key, pressed: false); held = false }
            }
    }
}
