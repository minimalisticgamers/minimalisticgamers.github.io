/* Presentation and accessibility for the unchanged bundled game. */
(function () {
  var lastPanel = null;
  var lastDialog = null;
  var previousFocus = null;
  var tooltipID = 0;
  var scheduled = false;
  function refresh() {
    scheduled = false;
    if (!window.Engine || !Engine.activeModule) return;
    var module = Engine.activeModule;
    var panel = module.panel && module.panel[0];
    var name = panel && panel.isConnected ? panel.id.replace('Panel', '').toLowerCase() : 'ending';
    if (document.body.dataset.nativeModule !== name) document.body.dataset.nativeModule = name;
    var dark = !!$SM.get('config.lightsOff');
    document.body.dataset.nativeDark = String(dark);
    document.querySelectorAll('.location').forEach(function (node) {
      var active = node === panel;
      if (node.classList.contains('native-active') !== active) node.classList.toggle('native-active', active);
      if (node.getAttribute('aria-hidden') !== String(!active)) node.setAttribute('aria-hidden', String(!active));
    });
    var header = document.getElementById('header');
    var notifications = document.getElementById('notifications');
    if (header && notifications && header.nextElementSibling !== notifications) header.after(notifications);
    var stores = document.getElementById('storesContainer');
    var main = document.getElementById('main');
    if (stores && main && stores.parentNode !== main) main.appendChild(stores);
    if (lastPanel && panel !== lastPanel) window.scrollTo(0, 0);
    lastPanel = panel;
    var width = document.getElementById('wrapper').clientWidth - (innerWidth <= 350 ? 28 : innerWidth >= 600 ? 56 : 40);
    var scale = Math.min(1, width / 700, Math.max(180, innerHeight - 24) / 700);
    document.documentElement.style.setProperty('--native-flight-scale', scale);
    document.documentElement.style.setProperty('--native-flight-height', (700 * scale) + 'px');
    document.querySelectorAll('.button, .headerButton, .menuBtn, .upBtn, .dnBtn, .upManyBtn, .dnManyBtn, .endGameOption').forEach(function (node) {
      node.setAttribute('role', 'button');
      node.setAttribute('tabindex', node.classList.contains('disabled') ? '-1' : '0');
      node.setAttribute('aria-disabled', String(node.classList.contains('disabled')));
      if (node.classList.contains('button')) {
        var title = Array.from(node.childNodes).filter(function (child) { return child.nodeType === 3; }).map(function (child) { return child.textContent; }).join('').trim();
        if (title) node.setAttribute('aria-label', title);
        var tooltip = node.querySelector('.tooltip');
        if (tooltip && !node.classList.contains('free')) {
          if (!tooltip.id) tooltip.id = 'native-cost-' + (++tooltipID);
          node.setAttribute('aria-describedby', tooltip.id);
        } else node.removeAttribute('aria-describedby');
      }
      if (node.classList.contains('headerButton')) node.setAttribute('aria-pressed', String(node.classList.contains('selected')));
      if (/^(up|dn)/.test(node.className)) {
        var row = node.closest('.workerRow, .outfitRow');
        var label = row && row.querySelector('.row_key');
        node.setAttribute('aria-label', (node.className.indexOf('up') === 0 ? 'Increase ' : 'Decrease ') + (label ? label.textContent : '') + (node.className.indexOf('Many') >= 0 ? ' by 10' : ' by 1'));
      }
    });
    if (notifications) {
      notifications.setAttribute('role', 'log');
      notifications.setAttribute('aria-live', 'polite');
      notifications.setAttribute('aria-relevant', 'additions');
      notifications.setAttribute('aria-label', 'Story');
    }
    var dialogs = Array.from(document.querySelectorAll('.eventPanel'));
    var dialog = dialogs.length ? dialogs[dialogs.length - 1] : null;
    document.querySelectorAll('#content, #native-game-menu, .logo').forEach(function (node) { node.inert = !!dialog; });
    var backdrop = document.getElementById('native-modal-backdrop');
    if (dialog && !backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'native-modal-backdrop';
      backdrop.setAttribute('aria-hidden', 'true');
      document.body.appendChild(backdrop);
    } else if (!dialog && backdrop) backdrop.remove();
    dialogs.forEach(function (node) {
      node.inert = node !== dialog;
      node.setAttribute('role', 'dialog');
      node.setAttribute('aria-modal', 'true');
      var title = node.querySelector('.eventTitle');
      if (title) node.setAttribute('aria-label', title.textContent);
    });
    if (dialog !== lastDialog) {
      if (dialog) {
        if (!lastDialog) previousFocus = document.activeElement;
        dialog.setAttribute('tabindex', '-1');
        dialog.focus({ preventScroll: true });
      } else if (previousFocus && previousFocus.isConnected) previousFocus.focus({ preventScroll: true });
      lastDialog = dialog;
    }
    var menu = document.querySelector('.menu');
    if (menu && !document.getElementById('native-game-menu')) {
      var details = document.createElement('details');
      details.id = 'native-game-menu';
      var summary = document.createElement('summary');
      summary.textContent = 'Game options';
      details.appendChild(summary);
      document.getElementById('wrapper').appendChild(details);
      details.appendChild(menu);
      var language = menu.querySelector('.customSelect');
      if (language) {
        var label = document.createElement('label');
        label.id = 'native-language';
        label.textContent = 'Language';
        var select = document.createElement('select');
        select.setAttribute('aria-label', 'Language');
        language.querySelectorAll('li[data-language]').forEach(function (item) {
          var option = document.createElement('option');
          option.value = item.dataset.language;
          option.textContent = item.textContent;
          select.appendChild(option);
        });
        select.value = localStorage.lang || 'en';
        select.addEventListener('change', function () {
          var item = language.querySelector('li[data-language="' + select.value + '"]');
          if (item) item.click();
        });
        label.appendChild(select);
        menu.appendChild(label);
      }
      var logo = document.querySelector('.logo');
      if (logo) details.after(logo);
    }
  }
  window.__nativeRefreshLayout = refresh;
  function schedule() {
    if (!scheduled) { scheduled = true; requestAnimationFrame(refresh); }
  }
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  addEventListener('resize', schedule);
  document.addEventListener('click', schedule);
  ['keydown', 'keyup'].forEach(function (type) {
    document.addEventListener(type, function (event) {
      if (event.target.matches('input, textarea, select')) event.stopPropagation();
    }, true);
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Tab' && lastDialog) {
      var controls = Array.from(lastDialog.querySelectorAll('[tabindex="0"], textarea, input, select, button, a[href]')).filter(function (node) { return node.getClientRects().length > 0; });
      if (controls.length) {
        var first = controls[0], last = controls[controls.length - 1];
        if (event.shiftKey && (document.activeElement === first || document.activeElement === lastDialog)) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && (document.activeElement === last || document.activeElement === lastDialog)) { event.preventDefault(); first.focus(); }
      } else event.preventDefault();
    }
    if (event.key !== 'Enter' && event.key !== ' ') return;
    var target = event.target;
    if (target.matches('[role="button"]') && !target.classList.contains('disabled')) {
      event.preventDefault();
      target.click();
    }
  });
  refresh();
})();
