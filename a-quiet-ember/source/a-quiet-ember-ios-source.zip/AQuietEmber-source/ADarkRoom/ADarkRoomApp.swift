import SwiftUI

@main
struct ADarkRoomApp: App {
    @StateObject private var game = OriginalGameController.forLaunch()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(game)
                .tint(.black)
                .preferredColorScheme(game.isDark ? .dark : .light)
                .onChange(of: scenePhase) { _, phase in
                    if phase != .active { game.releaseDirections(); game.persistForLifecycle() }
                }
        }
    }
}
