import Foundation
import CoreFoundation

/// A lossless envelope around the original browser's storage values.
/// Gameplay, preferences, cooldowns, and prestige all live inside gameState.
struct OriginalSave: Codable, Equatable {
    static let formatName = "ADarkRoom.WebSave"
    static let allowedKeys: Set<String> = ["gameState", "lang"]
    static let supportedLanguages: Set<String> = [
        "cs", "de", "el", "en", "eo", "es", "fr", "gl", "id", "it", "lv", "ja", "ko",
        "nb", "pl", "lt_LT", "pt", "pt_br", "ru", "sv", "th", "tr", "uk", "vi", "zh_cn", "zh_tw"
    ]
    let format: String
    let schemaVersion: Int
    let values: [String: String]

    init(values: [String: String]) throws {
        format = Self.formatName
        schemaVersion = 1
        self.values = values
        try validate()
    }

    init(data: Data) throws {
        guard data.count <= 8_000_000 else { throw OriginalGameError.invalidSave }
        self = try JSONDecoder().decode(Self.self, from: data)
        try validate()
    }

    func validate() throws {
        guard format == Self.formatName else { throw OriginalGameError.invalidSave }
        guard schemaVersion == 1 else { throw OriginalGameError.futureSave }
        guard Set(values.keys).isSubset(of: Self.allowedKeys),
              let rawState = values["gameState"], rawState.utf8.count <= 6_000_000,
              let data = rawState.data(using: .utf8),
              let state = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              !state.isEmpty else { throw OriginalGameError.invalidSave }

        // StateManager creates these dictionaries for a normal run. An original
        // restart can save only `previous`, before init() recreates the others.
        // Keep both valid forms and leave migration of old saves to the engine.
        let categories = ["features", "stores", "character", "income", "timers", "game", "playStats", "previous", "outfit", "config", "wait", "cooldown"]
        guard categories.contains(where: { state[$0] is [String: Any] }) else { throw OriginalGameError.invalidSave }
        for key in categories where state[key] != nil {
            guard state[key] is [String: Any] else { throw OriginalGameError.invalidSave }
        }
        if let version = state["version"] {
            guard let number = version as? NSNumber,
                  CFGetTypeID(number) != CFBooleanGetTypeID(),
                  number.doubleValue.isFinite, number.doubleValue >= 1 else {
                throw OriginalGameError.invalidSave
            }
        }
        // Room restores these enum objects directly, then looks their values
        // up in its five-level tables. An unknown value crashes initialization.
        // Missing enum values remain valid: the original engine initializes
        // them itself, including for older and prestige-only saves.
        if let game = state["game"] as? [String: Any] {
            for key in ["fire", "temperature"] {
                if let level = game[key] as? [String: Any], let value = level["value"] {
                    guard let number = value as? NSNumber,
                          CFGetTypeID(number) != CFBooleanGetTypeID(),
                          number.doubleValue.isFinite,
                          (0...4).contains(number.doubleValue),
                          number.doubleValue.rounded() == number.doubleValue else {
                        throw OriginalGameError.invalidSave
                    }
                }
            }
        }
        // Each income source is dereferenced during room setup and collection.
        // A malformed source can stop initialization or production.
        if let income = state["income"] as? [String: Any] {
            guard income.values.allSatisfy({ $0 is [String: Any] }) else {
                throw OriginalGameError.invalidSave
            }
        }
        if let lang = values["lang"], !Self.supportedLanguages.contains(lang) { throw OriginalGameError.invalidSave }
    }

    func encoded() throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return try encoder.encode(self)
    }

    var restorationScript: String {
        let json = String(decoding: try! JSONEncoder().encode(values), as: UTF8.self)
        return """
        (function() {
          // An existing gameState includes a restart's prestige-only state.
          // It always wins over the native backup from an earlier run.
          if (localStorage.getItem('gameState') === null) {
            var backup = \(json);
            Object.keys(backup).forEach(function(key) {
              if (localStorage.getItem(key) === null) localStorage.setItem(key, backup[key]);
            });
          }
        })();
        """
    }
}

struct OriginalSaveRepository {
    let directory: URL
    var primary: URL { directory.appendingPathComponent("original-save.json") }
    var previous: URL { directory.appendingPathComponent("original-save-previous.json") }

    init(directory: URL? = nil) {
        self.directory = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("OriginalADarkRoom", isDirectory: true)
    }

    func load() throws -> OriginalSave? {
        guard FileManager.default.fileExists(atPath: primary.path) else { return try readIfPresent(previous) }
        do { return try OriginalSave(data: Data(contentsOf: primary)) }
        catch OriginalGameError.futureSave { throw OriginalGameError.futureSave }
        catch {
            if let backup = try readIfPresent(previous) { return backup }
            throw error
        }
    }

    func save(_ save: OriginalSave) throws {
        try save.validate()
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        if FileManager.default.fileExists(atPath: primary.path) {
            do {
                _ = try OriginalSave(data: Data(contentsOf: primary))
                try Data(contentsOf: primary).write(to: previous, options: .atomic)
            } catch OriginalGameError.futureSave { throw OriginalGameError.futureSave }
            catch is DecodingError { }
            catch OriginalGameError.invalidSave { }
        }
        try save.encoded().write(to: primary, options: .atomic)
    }

    func remove() throws {
        for url in [primary, previous] where FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
    }

    private func readIfPresent(_ url: URL) throws -> OriginalSave? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        return try OriginalSave(data: Data(contentsOf: url))
    }
}
