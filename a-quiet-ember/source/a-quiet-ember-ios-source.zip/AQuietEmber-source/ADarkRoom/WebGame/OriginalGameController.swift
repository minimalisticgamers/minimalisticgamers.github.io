import Foundation
import WebKit
import UIKit
import Combine

@MainActor
final class OriginalGameController: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published private(set) var isLoaded = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var needsDirectionalControls = false
    @Published private(set) var isDark = false
    let webView: WKWebView
    let source: OriginalSource?
    private let repository: OriginalSaveRepository?
    private var starting = false
    private var originalSourceError: Error?

    static let networkRules = """
    [
      {"trigger":{"url-filter":"^http://"},"action":{"type":"block"}},
      {"trigger":{"url-filter":"^https://"},"action":{"type":"block"}},
      {"trigger":{"url-filter":"^ws://"},"action":{"type":"block"}},
      {"trigger":{"url-filter":"^wss://"},"action":{"type":"block"}}
    ]
    """

    init(dataStore: WKWebsiteDataStore? = nil, repository: OriginalSaveRepository? = OriginalSaveRepository()) {
        self.repository = repository
        let config = WKWebViewConfiguration()
        config.websiteDataStore = dataStore ?? .default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        do {
            let verified = try OriginalSource()
            source = verified
            config.setURLSchemeHandler(OriginalAssetHandler(source: verified), forURLScheme: "adarkroom")
        } catch {
            source = nil
            originalSourceError = error
        }
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.customUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = true
        webView.backgroundColor = .white
        webView.scrollView.backgroundColor = .white
        #if DEBUG
        webView.isInspectable = true
        #endif
    }

    static func forLaunch() -> OriginalGameController {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--ui-testing") {
            return OriginalGameController(dataStore: .nonPersistent(), repository: nil)
        }
        #endif
        return OriginalGameController()
    }

    func start() async {
        guard !starting, !isLoaded else { return }
        starting = true
        errorMessage = nil
        defer { starting = false }
        do {
            if let originalSourceError { throw originalSourceError }
            guard source != nil else { throw OriginalGameError.missingSource }
            let rules = try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<WKContentRuleList, Error>) in
                WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "OriginalADarkRoom-LocalOnly-v1", encodedContentRuleList: Self.networkRules) { rules, error in
                    if let error { continuation.resume(throwing: error) }
                    else if let rules { continuation.resume(returning: rules) }
                    else { continuation.resume(throwing: URLError(.unknown)) }
                }
            }
            let content = webView.configuration.userContentController
            content.removeAllContentRuleLists()
            content.add(rules)
            try configureScripts(backup: repository?.load())
            webView.load(URLRequest(url: URL(string: OriginalSource.origin + "/")!))
        } catch { errorMessage = error.localizedDescription }
    }

    /// Only presentation is adapted. No timer, random-number, or game function
    /// is replaced, intercepted, or accelerated by the host.
    private func configureScripts(backup: OriginalSave?) throws {
        let content = webView.configuration.userContentController
        content.removeAllUserScripts()
        if let backup {
            content.addUserScript(WKUserScript(source: backup.restorationScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        }
        guard let cssURL = Bundle.main.url(forResource: "mobile-layout", withExtension: "css"),
              let layoutURL = Bundle.main.url(forResource: "mobile-layout", withExtension: "js") else {
            throw OriginalGameError.missingSource
        }
        let css = try String(contentsOf: cssURL, encoding: .utf8)
        let layout = try String(contentsOf: layoutURL, encoding: .utf8)
        let literal = String(decoding: try JSONEncoder().encode(css), as: UTF8.self)
        let script = """
        (function() {
          var viewport = document.createElement('meta');
          viewport.name = 'viewport';
          viewport.content = 'width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=yes';
          (document.head || document.documentElement).appendChild(viewport);
          var style = document.createElement('style');
          style.id = 'native-viewport-layout';
          style.textContent = \(literal);
          (document.head || document.documentElement).appendChild(style);
          \(layout)
        })();
        """
        content.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
    }

    func evaluate(_ script: String) async throws -> Any {
        try await withCheckedThrowingContinuation { continuation in
            webView.evaluateJavaScript(script) { value, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: value ?? NSNull()) }
            }
        }
    }

    func updatePresentation() async {
        guard isLoaded else { return }
        guard let status = try? await evaluate("window.__nativeRefreshLayout && window.__nativeRefreshLayout(); ({directions:!!(Engine.activeModule.panel && Engine.activeModule.panel[0].isConnected) && (Engine.activeModule===World || (Engine.activeModule===Space && !Space.done)),dark:!!$SM.get('config.lightsOff') || document.body.classList.contains('noMask')})") as? [String: Any] else { return }
        needsDirectionalControls = status["directions"] as? Bool ?? false
        isDark = status["dark"] as? Bool ?? false
    }

    func sendDirection(_ key: Int, pressed: Bool) {
        guard isLoaded, [37, 38, 39, 40].contains(key) else { return }
        // Remember the receiving module so cleanup cannot turn into tab
        // navigation if the player returns home while still holding a key.
        let script = """
        (function(){
          if(typeof Engine!=='object') return;
          var held=window.__nativeHeldKeys || (window.__nativeHeldKeys={});
          var key=\(key), event=jQuery.Event('\(pressed ? "keydown" : "keyup")',{which:key,keyCode:key});
          if(\(pressed ? "true" : "false")){
            if(held[key] || (Engine.activeModule!==World && Engine.activeModule!==Space)) return;
            held[key]=Engine.activeModule;
            Engine.keyDown(event);
          } else {
            var module=held[key];
            if(!module) return;
            delete held[key];
            if(Engine.activeModule===module) Engine.keyUp(event);
            else if(module.keyUp) module.keyUp(event);
          }
        })();
        """
        webView.evaluateJavaScript(script, completionHandler: nil)
    }

    func releaseDirections() {
        [37,38,39,40].forEach { sendDirection($0, pressed: false) }
    }

    private func capture(saveFirst: Bool) async throws -> OriginalSave {
        guard isLoaded else { throw OriginalGameError.notReady }
        let keys = String(decoding: try JSONEncoder().encode(OriginalSave.allowedKeys.sorted()), as: UTF8.self)
        let result = try await evaluate("""
        (function() {
          \(saveFirst ? "Engine.saveGame();" : "")
          var values = {};
          \(keys).forEach(function(key) {
            var value = localStorage.getItem(key);
            if (value !== null) values[key] = value;
          });
          return JSON.stringify(values);
        })();
        """)
        guard let json = result as? String, let data = json.data(using: .utf8) else { throw OriginalGameError.invalidSave }
        return try OriginalSave(values: JSONDecoder().decode([String: String].self, from: data))
    }

    func saveNow() async throws {
        let save = try await capture(saveFirst: true)
        try repository?.save(save)
        errorMessage = nil
    }

    func retry() async {
        if isLoaded {
            // A failed native backup does not unload the running game. Retry
            // that write in place instead of discarding its live progress.
            do { try await saveNow() }
            catch { errorMessage = "The game could not be backed up: " + error.localizedDescription }
        } else {
            await start()
        }
    }

    func exportSave() async throws -> Data {
        let save = try await capture(saveFirst: true)
        try repository?.save(save)
        return try save.encoded()
    }

    func importSave(_ data: Data) async throws {
        guard isLoaded else { throw OriginalGameError.notReady }
        let incoming = try OriginalSave(data: data)
        let values = String(decoding: try JSONEncoder().encode(incoming.values), as: UTF8.self)
        let keys = String(decoding: try JSONEncoder().encode(OriginalSave.allowedKeys.sorted()), as: UTF8.self)
        // Retain the existing complete original save until replacement succeeds.
        let current = try await capture(saveFirst: true)
        try repository?.save(current)
        let before = String(decoding: try JSONEncoder().encode(current.values), as: UTF8.self)
        try configureScripts(backup: nil)
        let replacement = """
        (function() {
          var keys = \(keys), before = \(before), incoming = \(values);
          try {
            keys.forEach(function(key) { localStorage.removeItem(key); });
            Object.keys(incoming).forEach(function(key) { localStorage.setItem(key, incoming[key]); });
          } catch (error) {
            keys.forEach(function(key) { localStorage.removeItem(key); });
            Object.keys(before).forEach(function(key) { localStorage.setItem(key, before[key]); });
            throw error;
          }
          return true;
        })();
        """
        do {
            _ = try await evaluate(replacement)
            try repository?.save(incoming)
        } catch {
            // Restore the former storage if native persistence also fails.
            _ = try? await evaluate("(function(){var keys=\(keys),before=\(before);keys.forEach(function(key){localStorage.removeItem(key);});Object.keys(before).forEach(function(key){localStorage.setItem(key,before[key]);});return true;})();")
            throw error
        }
        isLoaded = false
        webView.reload()
    }

    func resetRun() async throws {
        guard isLoaded else { throw OriginalGameError.notReady }
        try repository?.remove()
        try configureScripts(backup: nil)
        // Use the original restart, including its original prestige policy.
        _ = try await evaluate("Engine.deleteSave(); true;")
    }

    func persistForLifecycle() {
        guard isLoaded else { return }
        let token = UIApplication.shared.beginBackgroundTask(withName: "Save original adarkroom")
        Task { @MainActor in
            defer { if token != .invalid { UIApplication.shared.endBackgroundTask(token) } }
            do { try await saveNow() }
            catch { errorMessage = "The game could not be backed up: " + error.localizedDescription }
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { isLoaded = false }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        Task { @MainActor in
            do {
                let ready = try await evaluate("typeof Engine === 'object' && typeof Engine.saveGame === 'function' && typeof Room === 'object' && typeof $SM === 'object' && !!document.getElementById('roomPanel') && !!(Engine.activeModule && Engine.activeModule.panel && Engine.activeModule.panel[0].isConnected)")
                guard ready as? Bool == true else { throw OriginalGameError.missingSource }
                // Verify storage is usable at this custom-scheme origin before
                // claiming that the game has loaded and can retain progress.
                _ = try await evaluate("localStorage.setItem('__native_storage_check','1'); if(localStorage.getItem('__native_storage_check')!=='1') throw Error('Local storage unavailable'); localStorage.removeItem('__native_storage_check'); true;")
                // Restoration is one-shot. An original prestige/reset reload
                // must never resurrect the run that existed at app launch.
                try configureScripts(backup: nil)
                errorMessage = nil
                isLoaded = true
            } catch { errorMessage = error.localizedDescription }
        }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { errorMessage = error.localizedDescription }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { errorMessage = error.localizedDescription }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        isLoaded = false
        errorMessage = "The game process stopped. Reload to continue from its saved state."
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if source?.file(for: url) != nil {
            // The hosted audio loader concatenates window.location with audio/.
            // Keep a query-free root origin when the original language menu
            // navigates; the original index already reads localStorage.lang.
            if let language = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "lang" })?.value,
               OriginalSave.supportedLanguages.contains(language) {
                decisionHandler(.cancel)
                Task { @MainActor in
                    do {
                        if isLoaded { try await saveNow() }
                        let literal = String(decoding: try JSONEncoder().encode(language), as: UTF8.self)
                        _ = try await evaluate("localStorage.setItem('lang', \(literal)); true;")
                        webView.load(URLRequest(url: URL(string: OriginalSource.origin + "/")!))
                    } catch { errorMessage = error.localizedDescription }
                }
                return
            }
            decisionHandler(.allow); return
        }
        if (navigationAction.navigationType == .linkActivated || navigationAction.targetFrame == nil), ["https", "http"].contains(url.scheme?.lowercased() ?? "") {
            UIApplication.shared.open(url)
        }
        decisionHandler(.cancel)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil,
           let url = navigationAction.request.url, ["https", "http"].contains(url.scheme?.lowercased() ?? "") {
            UIApplication.shared.open(url)
        }
        return nil
    }

    private var presenter: UIViewController? {
        var current = webView.window?.rootViewController
        while let next = current?.presentedViewController { current = next }
        return current
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let presenter else { completionHandler(); return }
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        presenter.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let presenter else { completionHandler(false); return }
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        presenter.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        guard let presenter else { completionHandler(nil); return }
        let alert = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        alert.addTextField { $0.text = defaultText }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(alert.textFields?.first?.text) })
        presenter.present(alert, animated: true)
    }
}
