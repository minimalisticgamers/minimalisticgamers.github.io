import Foundation
import CryptoKit
import WebKit

enum OriginalGameError: LocalizedError {
    case missingSource, invalidSource(String), invalidSave, futureSave, notReady

    var errorDescription: String? {
        switch self {
        case .missingSource: return "The original game files are missing from this build."
        case .invalidSource(let file): return "The original game file could not be verified: \(file)."
        case .invalidSave: return "This file is not a valid original-game save."
        case .futureSave: return "This save backup needs a newer version of the app."
        case .notReady: return "The game has not finished loading."
        }
    }
}

struct OriginalSource {
    struct Manifest: Decodable {
        struct File: Decodable {
            let path: String
            let sha256: String
            let sizeBytes: Int
        }
        let entryPoint: String
        let files: [File]
    }

    let directory: URL
    let manifest: Manifest
    static let origin = "adarkroom://game"
    private let filesByPath: [String: URL]

    init(directory: URL? = nil) throws {
        guard let directory = directory ?? Bundle.main.url(forResource: "ADarkRoom", withExtension: nil, subdirectory: "Vendor") else {
            throw OriginalGameError.missingSource
        }
        self.directory = directory
        let decoded = try JSONDecoder().decode(Manifest.self, from: Data(contentsOf: directory.appendingPathComponent("source-manifest.json")))
        manifest = decoded
        guard !manifest.files.isEmpty,
              Self.isSafeRelativePath(manifest.entryPoint),
              decoded.files.contains(where: { $0.path == decoded.entryPoint }) else {
            throw OriginalGameError.invalidSource("source-manifest.json")
        }
        var checked: [String: URL] = [:]
        let root = directory.resolvingSymlinksInPath().standardizedFileURL.path + "/"
        for file in manifest.files {
            guard Self.isSafeRelativePath(file.path), checked[file.path] == nil else { throw OriginalGameError.invalidSource(file.path) }
            let local = directory.appendingPathComponent(file.path)
            guard local.resolvingSymlinksInPath().standardizedFileURL.path.hasPrefix(root) else { throw OriginalGameError.invalidSource(file.path) }
            let data = try Data(contentsOf: local)
            let hash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
            guard data.count == file.sizeBytes, hash == file.sha256 else { throw OriginalGameError.invalidSource(file.path) }
            checked[file.path] = local
        }
        filesByPath = checked
    }

    private static func isSafeRelativePath(_ path: String) -> Bool {
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\"), !path.contains("\0") else { return false }
        return path.split(separator: "/", omittingEmptySubsequences: false).allSatisfy { !$0.isEmpty && $0 != "." && $0 != ".." }
    }

    func file(for url: URL) -> URL? {
        guard url.scheme == "adarkroom", url.host == "game", url.user == nil, url.password == nil, url.port == nil,
              let path = URLComponents(url: url, resolvingAgainstBaseURL: false)?.percentEncodedPath,
              path.hasPrefix("/"),
              let name = String(path.dropFirst()).removingPercentEncoding else { return nil }
        // The hosted audio engine appends relative asset paths to location.
        // Keep its document URL at the same slash root as the original site.
        if name.isEmpty { return filesByPath[manifest.entryPoint] }
        guard Self.isSafeRelativePath(name) else { return nil }
        return filesByPath[name]
    }
}

/// Serves the frozen files directly, including nested scripts, translations and
/// audio. Query strings do not change which manifest-listed local file is served.
final class OriginalAssetHandler: NSObject, WKURLSchemeHandler {
    let source: OriginalSource
    init(source: OriginalSource) { self.source = source }

    static func range(_ header: String?, length: Int) -> Range<Int>? {
        guard let header, header.hasPrefix("bytes="), !header.contains(","), length > 0 else { return nil }
        let pieces = header.dropFirst(6).split(separator: "-", omittingEmptySubsequences: false)
        guard pieces.count == 2 else { return nil }
        if pieces[0].isEmpty, let suffix = Int(pieces[1]), suffix > 0 {
            return max(0, length - suffix)..<length
        }
        guard let first = Int(pieces[0]), first >= 0, first < length else { return nil }
        let last = pieces[1].isEmpty ? length - 1 : Int(pieces[1]) ?? -1
        guard last >= first else { return nil }
        return first..<(min(last, length - 1) + 1)
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url, let file = source.file(for: url) else {
            urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist)); return
        }
        do {
            let fullData = try Data(contentsOf: file)
            let rangeHeader = urlSchemeTask.request.value(forHTTPHeaderField: "Range")
            let requested = Self.range(rangeHeader, length: fullData.count)
            if rangeHeader != nil && requested == nil {
                let response = HTTPURLResponse(url: url, statusCode: 416, httpVersion: "HTTP/1.1", headerFields: ["Content-Range": "bytes */\(fullData.count)"])!
                urlSchemeTask.didReceive(response); urlSchemeTask.didFinish(); return
            }
            let data = requested.map { fullData.subdata(in: $0) } ?? fullData
            let mime: String
            switch file.pathExtension {
            case "html": mime = "text/html; charset=utf-8"
            case "js": mime = "application/javascript; charset=utf-8"
            case "css": mime = "text/css; charset=utf-8"
            case "mp3": mime = "audio/mpeg"
            case "flac": mime = "audio/flac"
            case "ogg": mime = "audio/ogg"
            case "wav": mime = "audio/wav"
            case "m4a": mime = "audio/mp4"
            case "json": mime = "application/json; charset=utf-8"
            case "svg": mime = "image/svg+xml"
            case "png": mime = "image/png"
            case "jpg", "jpeg": mime = "image/jpeg"
            case "gif": mime = "image/gif"
            case "ico": mime = "image/x-icon"
            case "woff": mime = "font/woff"
            case "woff2": mime = "font/woff2"
            case "txt", "md": mime = "text/plain; charset=utf-8"
            default: mime = "application/octet-stream"
            }
            var headers = ["Content-Type": mime, "Content-Length": "\(data.count)", "Accept-Ranges": "bytes", "Cache-Control": "no-cache"]
            if let requested { headers["Content-Range"] = "bytes \(requested.lowerBound)-\(requested.upperBound - 1)/\(fullData.count)" }
            let response = HTTPURLResponse(url: url, statusCode: requested == nil ? 200 : 206, httpVersion: "HTTP/1.1", headerFields: headers)!
            urlSchemeTask.didReceive(response)
            if urlSchemeTask.request.httpMethod != "HEAD" { urlSchemeTask.didReceive(data) }
            urlSchemeTask.didFinish()
        } catch { urlSchemeTask.didFailWithError(error) }
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) { }
}
