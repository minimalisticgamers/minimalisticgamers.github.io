# A Quiet Ember — corresponding iOS source

Version 1.0, build 3.

A Quiet Ember is an independent iPhone/iPad adaptation of the open-source browser game A Dark Room by Michael Townsend, doublespeak games, and contributors. It is separate from the official A Dark Room mobile edition and is not affiliated with or endorsed by the original creators.

The original game and native host are provided under the Mozilla Public License 2.0. See LICENSE.md, the retained vendor licenses, and the bundled third-party notices. The license does not grant rights to the original game’s trademarks.

Open ADarkRoom.xcodeproj in Xcode, select the ADarkRoom scheme, and run on an iOS Simulator. The deployment target is iOS 17. A device build requires a signing team and a bundle identifier you control. Internal project and executable filenames remain ADarkRoom.

Vendor/ contains the pinned original browser runtime. Scripts/vendor_original.py --verify verifies its recorded hashes without refreshing it. The native host in ADarkRoom/ provides local loading, touch controls, responsive presentation, and user-selected save import/export.

Original game: https://adarkroom.doublespeakgames.com/
Original repository: https://github.com/doublespeakgames/adarkroom
Pinned preferred source: https://github.com/doublespeakgames/adarkroom/tree/1fada4620b6c66bd07bf15a3f1eb8223df8bc1d7
PreferredTranslationSource/ contains the 25 editable .po translations, template, converter, supporting docs and license from that exact commit, with per-file Git blob and SHA-256 verification. The separately included Vendor/ tree preserves the actual hosted runtime and its recorded differences.
Adaptation: https://minimalisticgamers.github.io/a-quiet-ember/
Support: https://minimalisticgamers.github.io/a-quiet-ember/support/

This package excludes developer credentials, .git history, private account/review documentation, tests and build outputs. Original upstream author and license notices remain intact.
